# -*- coding: utf-8 -*-
"""
Created on Tue Oct  5 14:30:55 2021

@author: vipvi
"""
import fitz

txt = []
doc = fitz.open("sample.pdf")
for i in range(len(doc)):            # some existing PDF
    page = doc[i]
    text = page.getText("text")
    txt = list(text)
    text = text.split('\n')
    txt = list(text)
with open('output.txt','w') as f: 
    f.write(txt)